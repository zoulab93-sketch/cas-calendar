Cas Calendar V1.4

Nouveautés :
- remplace automatiquement le cas existant d’un jour au lieu de créer un doublon ;
- relit les cas présents dans Google Calendar à l’ouverture et lors du changement de mois ;
- mémorise l’agenda Google choisi dans le navigateur ;
- conserve la compatibilité avec les événements créés par V1.3.

Utilisation : remplacer index.html dans le dépôt GitHub Pages par celui-ci.
